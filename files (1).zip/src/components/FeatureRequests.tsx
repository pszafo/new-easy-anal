import React from 'react';

const FeatureRequests: React.FC = () => {
  return (
    <div>
      <h1>Feature Requests</h1>
      <p>Gather and prioritize new feature requests from users.</p>
    </div>
  );
};

export default FeatureRequests;