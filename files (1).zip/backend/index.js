const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();
const port = process.env.PORT || 5000;

app.use(cors());
app.use(bodyParser.json());

app.get('/api/dashboard-data', (req, res) => {
  const data = {
    message: "Welcome to Zafo.ai Analytics Tool Dashboard.",
    stats: {
      users: 100,
      churnRate: 5,
      featureRequests: 10
    }
  };
  res.json(data);
});

app.post('/api/search', (req, res) => {
  const { query } = req.body;
  const response = {
    query,
    result: `Mock result for query: "${query}"`
  };
  res.json(response);
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});