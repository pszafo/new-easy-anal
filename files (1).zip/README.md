# User Tracker

This project is a user tracking tool that tracks user interactions such as clicks and scrolls on a client's software. The collected data is stored in a Google Sheet, and a UI is provided to run data science queries on the collected data.

## Project Structure

```
/user-tracker
  /client
    /public
    /src
      /components
      App.tsx
      index.tsx
    package.json
    tsconfig.json
  /server
    /routes
    index.js
    nlpService.js
    googleSheetService.js
    package.json
  .gitignore
  README.md
```

## Setup

### Frontend

1. Navigate to the `client` directory:
   ```sh
   cd client
   ```

2. Install dependencies:
   ```sh
   npm install
   ```

3. Run the development server:
   ```sh
   npm start
   ```

4. Build the project:
   ```sh
   npm run build
   ```

### Backend

1. Navigate to the `server` directory:
   ```sh
   cd server
   ```

2. Install dependencies:
   ```sh
   npm install
   ```

3. Run the server:
   ```sh
   npm start
   ```

## Deployment

To deploy the application, ensure that the build output from the frontend is placed in the correct location for the backend to serve. Follow the project structure and deployment steps outlined in this README.

### Environment Variables

- `OPENAI_API_KEY`: Your OpenAI API key.
- `GOOGLE_APPLICATION_CREDENTIALS`: Path to your Google service account JSON key file.

## Usage

Access the application in your browser at the appropriate URL (e.g., `http://localhost:5000` for local development or the deployed URL).

Navigate to different pages using the links provided in the application or by directly accessing routes like `/search` in the address bar.