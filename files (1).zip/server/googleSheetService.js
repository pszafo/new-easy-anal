const { google } = require('googleapis');

const sheets = google.sheets('v4');
const SPREADSHEET_ID = '1mQjK9KdQZKlHD6rChAmXlCLA13rHgz4XpLJH4uqWmFM';

const authenticateGoogle = async () => {
  const auth = new google.auth.GoogleAuth({
    keyFile: 'path/to/your/service-account-file.json',
    scopes: ['https://www.googleapis.com/auth/spreadsheets'],
  });

  return await auth.getClient();
};

const storeEvent = async (event, data) => {
  const auth = await authenticateGoogle();

  const request = {
    spreadsheetId: SPREADSHEET_ID,
    range: 'Sheet1!A1',
    valueInputOption: 'RAW',
    insertDataOption: 'INSERT_ROWS',
    resource: {
      values: [[new Date().toISOString(), event, JSON.stringify(data)]],
    },
    auth,
  };

  await sheets.spreadsheets.values.append(request);
};

module.exports = { storeEvent };