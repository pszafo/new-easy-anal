const express = require('express');
const { interpretQuery } = require('../nlpService');

const router = express.Router();

router.post('/', async (req, res) => {
  const { query } = req.body;

  try {
    const interpretedQuery = await interpretQuery(query);
    res.json({ interpretedQuery });
  } catch (error) {
    console.error('Error performing search', error);
    res.status(500).send('Internal Server Error');
  }
});

module.exports = router;