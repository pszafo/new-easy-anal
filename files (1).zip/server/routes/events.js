const express = require('express');
const { storeEvent } = require('../googleSheetService');

const router = express.Router();

router.post('/', async (req, res) => {
  const { event, data } = req.body;

  try {
    await storeEvent(event, data);
    res.status(200).send('Event stored successfully');
  } catch (error) {
    console.error('Error storing event', error);
    res.status(500).send('Internal Server Error');
  }
});

module.exports = router;