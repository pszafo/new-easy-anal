import React, { useEffect } from 'react';
import axios from 'axios';

const Dashboard: React.FC = () => {
  useEffect(() => {
    const trackEvent = (event: string, data: any) => {
      axios.post('/api/events', { event, data });
    };

    const handleClick = (e: MouseEvent) => {
      trackEvent('click', { x: e.clientX, y: e.clientY });
    };

    const handleScroll = () => {
      trackEvent('scroll', { scrollX: window.scrollX, scrollY: window.scrollY });
    };

    document.addEventListener('click', handleClick);
    window.addEventListener('scroll', handleScroll);

    return () => {
      document.removeEventListener('click', handleClick);
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  return (
    <div>
      <h1>Dashboard</h1>
      <p>Track user interactions on this page.</p>
    </div>
  );
};

export default Dashboard;