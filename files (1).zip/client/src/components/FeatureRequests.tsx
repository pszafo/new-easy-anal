import React from 'react';

const FeatureRequests: React.FC = () => {
  return (
    <div>
      <h1>Feature Requests</h1>
      <p>Content for feature requests</p>
    </div>
  );
};

export default FeatureRequests;